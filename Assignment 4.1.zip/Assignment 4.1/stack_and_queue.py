import time
import random

class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def insert(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node

    def remove(self, data):
        current = self.head
        while current:
            if current.data == data:
                if current.prev:
                    current.prev.next = current.next
                if current.next:
                    current.next.prev = current.prev
                if current == self.head:
                    self.head = current.next
                if current == self.tail:
                    self.tail = current.prev
                return
            current = current.next

    def print_list(self):
        elements = []
        current = self.head
        while current:
            elements.append(current.data)
            current = current.next
        print(elements)

class Stack:
    def __init__(self):
        self.dll = DoublyLinkedList()

    def insert(self, data):
        self.dll.insert(data)

    def remove(self, data):
        self.dll.remove(data)

    def print_stack(self):
        self.dll.print_list()

class Queue:
    def __init__(self):
        self.dll = DoublyLinkedList()

    def insert(self, data):
        self.dll.insert(data)

    def remove(self, data):
        self.dll.remove(data)

    def print_queue(self):
        self.dll.print_list()

def performance_test():
    sizes = [100, 1000, 10000]
    stack = Stack()
    queue = Queue()
    
    print("Performance Testing:")
    print("Insert:")
    for size in sizes:
        data = [random.randint(1, 10000) for _ in range(size)]

        start_time = time.time()
        for num in data:
            stack.insert(num)
        stack_time = time.time() - start_time

        start_time = time.time()
        for num in data:
            queue.insert(num)
        queue_time = time.time() - start_time

        print(f"  {size} elements: Stack - {stack_time:.6f}s, Queue - {queue_time:.6f}s")

    print("\nDelete:")
    for size in sizes:
        data = [random.randint(1, 10000) for _ in range(size)]

        start_time = time.time()
        for num in data:
            stack.remove(num)
        stack_time = time.time() - start_time

        start_time = time.time()
        for num in data:
            queue.remove(num)
        queue_time = time.time() - start_time

        print(f"  {size} elements: Stack - {stack_time:.6f}s, Queue - {queue_time:.6f}s")

if __name__ == "__main__":
    performance_test()
